1.you have to download this folder and install xampp on your desktop or pc .
2.after installtion on your web browser simply enter localhost and then in phpmyadmin create a database called grilli and in that create a table called book a table and in that insert the fields such as name mail phone message 
3.if you want to  see the details of book table you have to login from admin page and then you can access the details
4.After this all you can have fully access to the website.
5.Thanks for downloading this folder 
